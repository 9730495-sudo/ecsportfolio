// Beth Chipman | 4/14/26 | TankGame
PImage bg;
Tank tank1;
ArrayList<Obstacle> obstacles = new ArrayList<Obstacle>();
ArrayList<Projectile> projectile = new ArrayList<Projectile>();
ArrayList<PowerUp>powerups = new ArrayList<PowerUp>();
int score;
Timer obsTimer, puTimer;

void setup() {
  size(500, 500);
  bg = loadImage("BackgroundforTankGame.png");
  tank1 = new Tank();
  score = 0;
  obsTimer = new Timer(1000);
  obsTimer.start();
  puTimer = new Timer(5000);
  puTimer.start();
}

void draw() {
  background(127);
  imageMode(CORNER);
  image(bg, 0, 0);
  // Add timer to distribute obstacles
  if (obsTimer.isFinished()) {
    //add objects
    obstacles.add (new Obstacle(-100, int(random(height))));
    obsTimer.start();
  }
  // Add timer to powerups on a timer
  if (puTimer.isFinished()) {
    //add power up
    powerups.add (new PowerUp());
    //restart timer
    puTimer.start();
  }
  //Display and remove powerups
  for (int i = 0; i < powerups.size(); i++) {
    PowerUp pu = powerups.get(i);
    pu.display();
    pu.move();
    if (pu.reachedEdge()) {
      powerups.remove(pu);
    }
    if (pu.intersect(tank1)) {
      if (pu.type == 'h') {
        tank1.health = tank1.health + 100;
        powerups.remove(pu);
      } else if (pu.type == 'a') {
        tank1.laserCount =tank1.laserCount + 100;
        powerups.remove(pu);
      } else if (pu.type == 't') {
        tank1.turretCount =tank1.turretCount +1;
        powerups.remove(pu);
      }
    }
  }
  //dsiplaying obstacles
  for (int i = 0; i < obstacles.size(); i++) {
    Obstacle o = obstacles.get(i);
    o.display();
    o.move();
    if (o.reachedEdge()) {
      obstacles.remove(o);
    }
    //detect collision to tank
    if (tank1.intersect(o)) {
      tank1.health = tank1. health -100;
      obstacles.remove(o);
      //impact to change score,health, and obstacle
    }
  }

  //dsiplaying projectiles
  for (int i = 0; i < projectile.size(); i++) {
    Projectile p = projectile.get(i);
    for (int j = 0; j < obstacles.size(); i++) {
      Obstacle o = obstacles.get(j);
      if (p.intersect(o)) {
        score = score + 100;
        projectile.remove(i);
        obstacles.remove(j);
        continue;
      }
    }
    p.display();
    p.move();
    if (p.reachedEdge()) {
      projectile.remove(i);
    }
    println ("Objects in Memory;" +obstacles.size());
    println ("Projectiles in Memory:" +projectile.size());
  }
  tank1.display();
  scorePanel();
  
}


void scorePanel() {
  fill(127, 127);
  rectMode(CENTER);
  rect(width/2, 40, width, 35);
  fill(255);
  textSize(30);
  textAlign(CENTER);
  text("Score:" + score, width/2, 50);
  text("Health:" + tank1.health, width/2-150, 50);
  text("Ammo:" + tank1.laserCount, width/2+150, 50);
}

void keyPressed () {
  if (key == 'w') {
    tank1.move ('w');
  } else if (key == 's') {
    tank1.move ('s');
  } else if (key == 'd') {
    tank1.move ('d');
  } else if (key == 'a') {
    tank1.move ('a');
  }
}

void mousePressed() {
  if (tank1.turretCount == 1) {
    projectile.add(new Projectile(tank1.x, tank1.y));
  } else if (tank1.turretCount==2) {
    projectile.add(new Projectile(tank1.x+10, tank1.y+10));
  }
}
