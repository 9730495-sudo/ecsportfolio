class Tank {
  //member variable
  int x, y, w, h, speed, health;
  PImage t1, t2, t3, t4;
  char idir;
  int turretCount, laserCount;

  //Contstructor
  Tank() {
    x = 100;
    y = 100;
    w = 100;
    h =  100;
    speed=20;
    health = 100;
    t1 = loadImage("greytank4.png");
    t2 = loadImage("greytank2.png");
    t3 = loadImage("greytank1.png");
    t4 = loadImage("greytank3.png");
    idir = 'w';
    turretCount = 1;
    laserCount = 100;
  }

  void display() {
    imageMode(CENTER);
    if (idir == 'w') {
      image (t3, x, y);
    } else if (idir == 'a') {
      image (t2, x, y) ;
    } else if (idir == 's') {
      image (t4, x, y);
    } else if (idir == 'd') {
      image (t1, x, y) ;
    }
  }

  void move(char dir) {
    if (dir == 'w') {
      idir = 'w';
      y = y - speed;
    } else if (dir == 's') {
      idir = 'w';
      y = y + speed;
    } else if (dir == 'a') {
      idir = 'a';
      x = x - speed;
    } else if (dir == 'd') {
      idir = 'd';
      x = x + speed;
    }
  }
  
  boolean intersect(Obstacle o) {
    float distance = dist (x, y, o.x, o.y);
    if (distance < 100) {
      return true;
    } else {
      return false;
    }
  }
  
  
}
