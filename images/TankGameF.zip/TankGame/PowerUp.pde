class PowerUp {
  float x, y, w, h, speed;
  char type;
  //PImage obst1;
  //char idir;

  //Contstructor
  PowerUp() {
    w  = 100;
    h = 100;
    speed = 5;
    x= random (width);
    y = -100;
    if (random(4) == 2) {
      type = 'h';//H is for health
    } else if (int(random(3)) == 1) {
      type = 't';//t is for turret
    } else {
      type ='a';//a is for ammo
    }
  }


  void display() {
    if (type == 'h') {
      fill (#DE2424);
      ellipse (x, y, w, h);
      fill (#FFFFFF);
      textAlign(CENTER, CENTER);
      text ("Health", x, y);
    } else if (type == 't') {
      fill (0, 0, 200);
      ellipse (x, y, w, h);
      fill (#FFFFFF);
      textAlign(CENTER, CENTER);
      text ("Turret", x, y);
    } else {
      fill (#054307);
      ellipse (x, y, w, h);
      fill (#FFFFFF);
      textAlign(CENTER, CENTER);
      text ("Ammo", x, y);
    }
  }

  void move() {

    y = y + speed;
  }

  boolean reachedEdge() {
    return x >= width+150 || x <= -150 || y > height + 150 || y < -150;
  }

  boolean intersect(Tank t) {
    float distance = dist (x, y, t.x, t.y);
    if (distance < 100) {
      return true;
    } else {
      return false;
    }
  }
}
