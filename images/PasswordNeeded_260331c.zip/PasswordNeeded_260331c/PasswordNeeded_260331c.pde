//Beth Chipman | Mar 26, 2026 | Password Needed
String correctPassword = "code";   
String userInput = "";             
boolean submitted = false;      
boolean access = false;           

void setup() {
  size(500, 400);
  textAlign(CENTER, CENTER);
}

void draw() {
  background(255);

  if (submitted) {
    if (access) background(0, 200, 0);   
    else background(200, 0, 0);          
  }

  // Draw top circle icon
  fill(255);
  stroke(0);
  strokeWeight(3);
  ellipse(width/2, 80, 100, 100);

  // Stick figure inside circle
  line(width/2, 60, width/2, 100);   
  ellipse(width/2, 45, 25, 25);     
  line(width/2, 75, width/2 - 20, 90); 
  line(width/2, 75, width/2 + 20, 90); 
  line(width/2, 100, width/2 - 15, 125); 
  line(width/2, 100, width/2 + 15, 125); 

  
  fill(0);
  textSize(32);
  text("Sign In", width/2, 160);

 
  stroke(0);
  strokeWeight(2);
  fill(255);
  rectMode(CENTER);
  rect(width/2, 230, 300, 50);

  textSize(20);
  fill(100);
  if (userInput.length() == 0) {
    text("Password Attempt Here", width/2, 230);
  } else {
    text(userInput, width/2, 230);
  }

  // Result message
  if (submitted) {
    textSize(28);
    fill(255);
    if (access) {
      text("ACCESS GRANTED", width/2, 320);
    } else {
      text("ACCESS DENIED", width/2, 320);
    }
  }
}

void keyPressed() {
  // Backspace
  if (key == BACKSPACE && userInput.length() > 0) {
    userInput = userInput.substring(0, userInput.length()-1);
    return;
  }

  // Submit on ENTER
  if (key == ENTER || key == RETURN) {
    submitted = true;
    access = userInput.equals(correctPassword);
    return;
  }

  // Add typed characters
  if (key != CODED) {
    userInput += key;
  }
}
